Here is the link
http://udagr-webap-nb50tmjywba9-565576969.us-east-1.elb.amazonaws.com/